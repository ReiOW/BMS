This sabun:
1. the animal SE has been cut. (28->2G~2L; 29-> 2N~2U; 2A-> 2W~33; 2B->3L~3S)
2. the acid B1 and B2 have been cut. (0J-> 0L,0M; 0K-> 0C,0D)
3. No key sound objects are added due to aesthetic.　(04)

この差分：
①　アニマル効果音が切られた。(28->2G~2L; 29-> 2N~2U; 2A-> 2W~33; 2B->3L~3S)
②　acid B1 and B2が切られた。(0J-> 0L,0M; 0K-> 0C,0D)
③　美観のため、キー音ないオブジェが使われる。 (04)

[Dancing East African 1]：★２～★３（ｓｌ２）
[Dancing East African 2]：★７～★８（ｓｌ４）